TERMS OF USE
This Agreement governs the terms by which visitors of www.FreeTemplates.pro obtain the right to use all resources created by the team of FreeTemplates.pro. By downloading or using our products you imply that you have read and accepted these Terms of Use:

Authorized use:

All Free version files downloaded from www.FreeTemplates.pro are free for use in both personal and commercial projects. You can modify any resource to fit your taste, e.g. change colors, shapes, effects, etc. You can share our HTML files on your websites/blogs, however, a backlink to our website is required for free version downloads. For Pro version backlink or any credit is not required.

Unauthorized use:

You may not sell, resell, lease, license, sub-license our files.
You may not use our files for any pornographic or unlawful purpose, to defame a person, to violate a person�s right to privacy or publicity, to infringe upon any copyright, trade name, trademark, or service mark of any person/entity.

You may not use our files for any illegal or unauthorized purpose. 
You must not, in the use of our files, violate any laws in your jurisdiction.

Redistribution:

Feel free to redistribute our resources in any of your websites. However, when you share a Template file, you have to add a link to the specific resource page in FreeTemplates.pro.

Hotlinking:

Hotlinked files and images are not allowed. If you want to spread the word about our freebies, you have to link to the single page of the specific resource. Direct links to the zip file are not allowed. Nofollow links are also not allowed.

External links:

From time to time, our website may also include links to external websites. We put these links to give you more information about the product, e.g. fonts that need to be installed. However, we have no responsibility for the content of the linked websites.

Support:

We do not offer support, however if you need to contact us, please email to info (at ) freetemplates (dot ) pro. We will do our best to respond within 48 hours.

Warranty:

We are not legally liable for any misuse, any damages, loss of profits or other intangible losses.